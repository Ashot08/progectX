
    Mtfkn index!!!
    <br>
    <br>
<p><?php echo $hi; ?></p>
